/* what-tune - Audio fingerprint generator/comparison tool
   Copyright (C) 2007 Toby Smithe <tsmithe@ubuntu.com>
   Portions copyright (C) 2006 Gian-Carlo Pascutto
   
   Licensed under the GPLv3 as described in COPYING:

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/

#include <what-tune.h>
#define VERSION 2

int help();
int get_version();
int isfile(char *path);
int fpwrite(char *infile, char *outfile);
float fpcompare(char *fileA, char *fileB);
float fpread(char *fileA, char *fileB);

int main(int argc, char *argv[]) {
	wt_version version = wt_getVersion();
	printf("What-tune v%d (libwhat-tune v%d.%d) (C) 2007 Toby Smithe <tsmithe@ubuntu.com>\n", get_version(), version.major, version.minor);
	char *mode;
	int retval = 0;
	
	/* Check arguments */
	if (argc <= 1) {
		mode = "h";
	} else {
		mode = argv[1];
	}
	
	switch (mode[0]) {
	case 'w':
		if (argc < 4)
			retval = help(argv);
		else
			retval = fpwrite(argv[2], argv[3]);
		break;
		
	case 'c':
		if (argc < 4)
			retval = help(argv);
		else
			retval = (int) fpcompare(argv[2], argv[3]);
		break;
		
	case 'r':
		if (argc < 4)
			retval = help(argv);
		else
			retval = (int) fpread(argv[2], argv[3]);
		break;
		
	default:
		retval = help(argv);
	}
	
	return retval;
}

int help(char *argv[]) {
	printf("Usage: %s mode options\n\n", argv[0]);
	puts("mode can be any of:");
	puts("\twrite\t- Write a fingerprint of sound-file to fingerprint-file");
	puts("\t\tUsage: write sound-file fingerprint-file\n");
	puts("\tcompare\t- Compare the fingerprints of two sound files");
	puts("\t\tUsage: compare file1 file2\n");
	puts("\tread\t- Compare the fingerprint of a sound file to that in a\n\t\t  stored fingerprint");
	puts("\t\tUsage: read sound-file fingerprint-file\n");
	puts("\thelp\t- Display this message\n");
	return -1;
}

int get_version() {
	return VERSION;
}

int fpwrite(char *infile, char *outfile) {
	if (!(isfile(infile)))
		return 0;
	wt_data *data = malloc(sizeof(wt_data));
	data->data = (void *) infile;	
	int result = wt_generateFingerprint(data);
	data->data = (void *) outfile;
	
	if (result != 0) {
		int bytes = wt_outputFingerprint(data);
		if (bytes > 0) {
			printf("Written %d bytes to %s\n", bytes, outfile);
		} else {
			fprintf(stderr, "Error writing %s\n", outfile, bytes);
		}
	fp_free(data->fid);		
	} 
	
	free(data);
	return 1;
}

float fpcompare(char *fileA, char *fileB) {
	if (!(isfile(fileA)) || !(isfile(fileB)))
		return 0;
	wt_data *dataA, *dataB;
	float conf = 0;
	int result;

	dataA = malloc(sizeof(wt_data));
	dataB = malloc(sizeof(wt_data));
	
	dataA->data = fileA;
	dataB->data = fileB;

	result = wt_generateFingerprint(dataA);
	if (result < 1) {
		free(dataA);
		free(dataB);
		return result;
	}

	result = wt_generateFingerprint(dataB);
	if (result < 1) {
		fp_free(dataA->fid);
		free(dataA);
		free(dataB);
		return result;
	}
	
	if (wt_possibleMatch(&(dataA->fid->fp), &(dataB->fid->fp)))
			conf = wt_fullMatch(&(dataA->fid->fp), &(dataB->fid->fp));
	printf("Match confidence: %f\n", conf);
	if (conf >= 0.5)
		puts("Most likely a match");
	
	fp_free(dataA->fid);
	fp_free(dataB->fid);
	free(dataA);
	free(dataB);
	return conf;
}

float fpread(char *fileA, char *fileB) {
	if (!(isfile(fileA)) || !(isfile(fileB)))
		return 0;
	wt_data *dataA, *dataB;
	float conf = 0;
	int result;

	dataA = malloc(sizeof(wt_data));
	dataB = malloc(sizeof(wt_data));
	
	dataA->data = fileA;
	dataB->data = fileB;
	
	result = wt_generateFingerprint(dataA);
	if (result < 1) {
		free(dataA);
		free(dataB);
		return result;
	}

	FILE *fd = fopen(fileB, "r");
	unsigned char *buff = malloc(fp_getsize(dataA->fid));
	fread(buff, fp_getsize(dataA->fid), 1, fd);
	
	if (wt_possibleMatch(&(dataA->fid->fp), (t_fingerprint *)buff))
			conf = wt_fullMatch(&(dataA->fid->fp), (t_fingerprint *)buff);
	printf("Match confidence: %f\n", conf);
	if (conf >= 0.5)
		puts("Most likely a match");
	
	fclose(fd);
	fp_free(dataA->fid);
	free(buff);
	free(dataA);
	free(dataB);
	return conf;
}

int isfile(char *path) {
	FILE *file = fopen(path, "r");
	if (file == NULL) {
		fprintf(stderr, "File error on %s: ", path);
		perror(NULL);
		return 0;
	} else {
		fclose(file);
		return 1;
	}
}

