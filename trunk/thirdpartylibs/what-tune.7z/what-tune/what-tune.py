#!/usr/bin/env python
#
#   what-tune - Audio fingerprint generator/comparison tool
#   Copyright (C) 2007 Toby Smithe <tsmithe@ubuntu.com>
#   Portions copyright (C) 2006 Gian-Carlo Pascutto
#   
#   Licensed under the GPLv3 as described in COPYING:
#
#   This program is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program.  If not, see <http://www.gnu.org/licenses/>.

import sys, pywhattune

def main(argv):
	if len(argv) < 3:
		sys.exit(-1)
	dataA = pywhattune.generateFingerprint(argv[1])
	dataB = pywhattune.generateFingerprint(argv[2])
	match = pywhattune.possibleMatch(dataA.fid, dataB.fid)
	if match:
		match = pywhattune.fullMatch(dataA.fid.fp, dataB.fid)
		print "Match probability:", match
		return match
	else:
		return 0


if __name__ == "__main__":
	main(sys.argv)
