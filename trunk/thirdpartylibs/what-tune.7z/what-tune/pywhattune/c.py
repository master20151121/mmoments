#   what-tune - Audio fingerprint generator/comparison tool
#   Copyright (C) 2007 Toby Smithe <tsmithe@ubuntu.com>
#   Portions copyright (C) 2006 Gian-Carlo Pascutto
#   
#   Licensed under the GPLv3 as described in COPYING:
#
#   This program is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program.  If not, see <http://www.gnu.org/licenses/>.

from ctypes import *
import sys

# Some defines from fooid.h
FRAME_LEN = 8192
SPEC_LEN = FRAME_LEN / 2
MAX_BARK = 17

# Set up structs
#
# t_fingerprint (fooid.h)
class c_t_fingerprint(Structure):
	_fields_ = [("version", c_short),	# Fingerprint version
		    ("length", c_int),		# Length in centiseconds
		    ("avg_fit", c_short),	# Average line fit, times 1000
		    ("avg_dom", c_short),	# Average dominant line, times 100
		    ("r", c_ubyte * 348),	# Spectral fits
		    ("d", c_ubyte * 6)]		# Spectral doms

# t_fooid (fooid.h)
class c_t_fooid(Structure):
	_fields_ = [# Spectral stuff
		    ("window", c_float * SPEC_LEN),
		    ("line_to_cb", c_int * SPEC_LEN),
		    ("cb_start", c_int * MAX_BARK),
		    ("cb_size", c_int * MAX_BARK),
		    ("max_sfb", c_int),

		    # Settings stuff
		    ("channels", c_int),
		    ("samplerate", c_int),

		    # Buffer stuff
		    ("samples", POINTER(c_float)),
		    ("sbuffer", POINTER(c_float)),
		    ("soundfound", c_int),

		    # Resampling stuff
		    ("resample_ratio", c_float),
		    ("resample_h", c_void_p),
		    ("outpos", c_int),

		    # Actual fingerprint
		    ("fp", c_t_fingerprint)]

# wt_data (what-tune.h)
class c_wt_data(Structure):
	_fields_ = [("fid", POINTER(c_t_fooid)),
		    ("data", c_void_p),
		    ("value", c_int)]
		    
# wt_version (what-tune.h)
class c_wt_version(Structure):
	_fields_ = [("major", c_int),
		    ("minor", c_int)]

# Load the library    
libwhattune = cdll.LoadLibrary("libwhat-tune.so")

# Set up function casts
#
# wt_getVersion: wt_version wt_getVersion();
c_wt_getVersion__ParamFlags = None
c_wt_getVersion__Prototype = CFUNCTYPE(c_wt_version)
c_wt_getVersion = c_wt_getVersion__Prototype(("wt_getVersion", libwhattune), c_wt_getVersion__ParamFlags)

# wt_generateFingerprint: wt_data * wt_generateFingerprint2(char *infile);
c_wt_generateFingerprint2__ParamFlags = (1, "infile"),
c_wt_generateFingerprint2__Prototype = CFUNCTYPE(POINTER(c_wt_data), c_char_p)
c_wt_generateFingerprint2 = c_wt_generateFingerprint2__Prototype(("wt_generateFingerprint2", libwhattune), c_wt_generateFingerprint2__ParamFlags)

# wt_outputFingerprint2: int wt_outputFingerprint2(t_fooid *fid, char *outfile);
c_wt_outputFingerprint2__ParamFlags = (1, "fid"), (1, "outfile", "/dev/null")
c_wt_outputFingerprint2__Prototype = CFUNCTYPE(c_int, POINTER(c_t_fooid), c_char_p)
c_wt_outputFingerprint2 = c_wt_outputFingerprint2__Prototype(("wt_outputFingerprint2", libwhattune), c_wt_outputFingerprint2__ParamFlags)

# wt_fullMatch: float wt_fullMatch(t_fingerprint *fpA, t_fingerprint *fpB);
c_wt_fullMatch__ParamFlags = (1, "fpA"), (1, "fpB")
c_wt_fullMatch__Prototype = CFUNCTYPE(c_float, POINTER(c_t_fingerprint), POINTER(c_t_fingerprint))
c_wt_fullMatch = c_wt_fullMatch__Prototype(("wt_fullMatch", libwhattune), c_wt_fullMatch__ParamFlags)

# wt_possibleMatch: int wt_possibleMatch(t_fingerprint *fpA, t_fingerprint *fpB);
c_wt_possibleMatch__ParamFlags = (1, "fpA"), (1, "fpB")
c_wt_possibleMatch__Prototype = CFUNCTYPE(c_int, POINTER(c_t_fingerprint), POINTER(c_t_fingerprint))
c_wt_possibleMatch = c_wt_possibleMatch__Prototype(("wt_possibleMatch", libwhattune), c_wt_possibleMatch__ParamFlags)

# Show libwhat-tune version
libwhattune_version = c_wt_getVersion()
sys.stderr.write("Using libwhat-tune v%d.%d\n" % (libwhattune_version.major, libwhattune_version.minor))
