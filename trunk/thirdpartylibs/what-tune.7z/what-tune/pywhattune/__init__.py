#!/usr/bin/env python
#
#   what-tune - Audio fingerprint generator/comparison tool
#   Copyright (C) 2007 Toby Smithe <tsmithe@ubuntu.com>
#   Portions copyright (C) 2006 Gian-Carlo Pascutto
#   
#   Licensed under the GPLv3 as described in COPYING:
#
#   This program is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program.  If not, see <http://www.gnu.org/licenses/>.

import sys
from ctypes import *
from c import *

class wt_data():
	def __init__(self, fid, data=None, value=None):
		try: 
			if fid.contents.samples:
				self.fid = fid.contents
		except:
			try:
				if fid.samples:
					self.fid = fid
			except:
				self.fid = None
		self.data = data
		self.value = value
		
class wt_version():
	def __init__(self, major, minor):
		if major is int:
			self.major = major
		else:
			self.major = 0
		if minor is int:
			self.minor = minor
		else:
			self.minor = 0
	
def getVersion():
	result = c_wt_getVersion()
	return wt_version(result.major, result.minor)	

def generateFingerprint(path):
	result = c_wt_generateFingerprint2(path).contents
	return wt_data(result.fid, result.data, result.value)
	
def outputFingerprint(fid, path="/dev/null"):
	try: 
		if fid.contents.samples:
			fid = fid
	except:
		try:
			if fid.samples:
				fid = byref(fid)
		except:
			return None
	return c_wt_outputFingerprint2(fid, path)
	
def possibleMatch(fpA, fpB):
	try:
		if fpA.fp:
			try:
				if fpA.fp.contents:
					fpA = fpA.fp.contents
			except:
				fpA = fpA.fp
	except: pass
	try:
		if fpB.fp:
			try:
				if fpB.fp.contents:
					fpB = fpB.fp.contents
			except:
				fpB = fpB.fp
	except: pass
	retval = 0
	try:
		if fpA.length:
			try:
				if fpB.length: 
					retval = c_wt_possibleMatch(fpA, fpB)
			except:
				try:
					if fpB.contents.length:
						retval = c_wt_possibleMatch(fpA, fpB.contents)
				except: pass
	except:
		try:
			if fpA.contents.length:
				try:
					if fpB.length:
						retval = c_wt_possibleMatch(fpA.contents, fpB)
				except:
					try:
						if fpB.contents.length:
							retval = c_wt_possibleMatch(fpA.contents, fpB.contents)
					except: pass
		except: pass
	return retval
	
def fullMatch(fpA, fpB):
	try:
		if fpA.fp:
			try:
				if fpA.fp.contents:
					fpA = fpA.fp.contents
			except:
				fpA = fpA.fp
	except: pass
	try:
		if fpB.fp:
			try:
				if fpB.fp.contents:
					fpB = fpB.fp.contents
			except:
				fpB = fpB.fp
	except: pass
	retval = 0
	try:
		if fpA.length:
			try:
				if fpB.length: 
					retval = c_wt_fullMatch(fpA, fpB)
			except:
				try:
					if fpB.contents.length:
						retval = c_wt_fullMatch(fpA, fpB.contents)
				except: pass
	except:
		try:
			if fpA.contents.length:
				try:
					if fpB.length:
						retval = c_wt_fullMatch(fpA.contents, fpB)
				except:
					try:
						if fpB.contents.length:
							retval = c_wt_fullMatch(fpA.contents, fpB.contents)
					except: pass
		except: pass
	return retval
	

if __name__ == "__main__":
	# Generate fingerprint, test functions
	if len(sys.argv) < 2:
		print "Need to supply path to sound file"
		sys.exit(-1)
	filename = sys.argv[1]
	
	print "Testing ctype prototyped methods..."
	data = c_wt_generateFingerprint2(filename).contents
	error = 0	
	if data.value:
		try:
			c_oF1 = c_wt_outputFingerprint2(data.fid)
			c_oF2 = c_wt_outputFingerprint2(pointer(data.fid.contents))
			if c_oF1 != c_oF2:
				error += 1
			c_pM = c_wt_possibleMatch(data.fid.contents.fp, data.fid.contents.fp)
			c_fM = c_wt_fullMatch(data.fid.contents.fp, data.fid.contents.fp)
 			print "output:", c_oF1
			print "output:", c_oF2
			print "possibleMatch:", c_pM
			print "fullMatch:", c_fM
		except Exception, e:
			print "Exception raised", e
			sys.exit(-2)
	else:
		print "Unable to generate fingerprint"
		sys.exit(-3)
	if error == 0:
		print "\nGood - ctype prototypes work great\n"
	elif error == 1:
		print "\nOK - ctypes prototypes work, but 1 error was encountered\n"
	else:
		print "\nOK - ctypes prototypes work, but %d errors were encountered\n" % error
	print "Testing wrapper methods..."
	data = generateFingerprint(filename)
	error = 0
	if data.value:
		try:
			oF1 = outputFingerprint(data.fid)
			oF2 = outputFingerprint(pointer(data.fid))
			if c_oF1 != c_oF2:
				print "Uhoh: outputFingerprint(data.fid) != outputFingerprint(pointer(data.fid))"
			pM = possibleMatch(data.fid.fp, pointer(data.fid.fp))
			fM = fullMatch(pointer(data.fid.fp), data.fid.fp)
			print "output:", oF1
			print "output:", oF2
			print "possibleMatch:", pM
			print "fullMatch:", fM
		except Exception, e:
			print "Exception raised", e
			sys.exit(-2)
	else:
		print "Unable to generate fingerprint"
		sys.exit(-3)
	if c_oF1 != oF1:
		print "Uhoh: c_wt_outputFingerprint(data.fid) != outputFingerprint(data.fid)"
		error += 1
	if c_oF2 != oF2:
		print "Uhoh: c_wt_outputFingerprint2(pointer(data.fid.contents)) != outputFingerprint(pointer(data.fid))"
		error += 1
	if c_pM != pM:
		print "Uhoh: c_wt_possibleMatch(data.fid.contents.fp, data.fid.contents.fp) != possibleMatch(data.fid.fp, pointer(data.fid.fp))"
		error += 1
	if c_fM != fM:
		print "Uhoh: c_wt_fullMatch(data.fid.contents.fp, data.fid.contents.fp) != fullMatch(pointer(data.fid.fp), data.fid.fp)"
		error += 1
	print "\nGood - wrapper methods work great; %d error(s) in comparison to C prototypes\n" % error
	print "Done"
