/* what-tune - Audio fingerprint generator/comparison tool
   Copyright (C) 2007 Toby Smithe <tsmithe@ubuntu.com>
   Portions copyright (C) 2006 Gian-Carlo Pascutto
   
   Licensed under the GPLv3 as described in COPYING:

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/

#include "what-tune.h"

wt_version wt_getVersion() {
	wt_version version;
	version.major = _LIB_WHAT_TUNE_VERSION_MAJOR;
	version.minor = _LIB_WHAT_TUNE_VERSION_MINOR;
	return version;
}

int wt_generateFingerprint(wt_data *data) {
	void *infile = (char *)data->data;
	fprintf(stderr, "Generating fingerprint for %s...\n", infile);

	/* Prepare SF_INFO struct */
	SF_INFO *sfinfo = malloc(sizeof(SF_INFO));
	sfinfo->format = 0;
	
	/* Open file */
	SNDFILE *sndfile = sf_open(infile, SFM_READ, sfinfo);
	
	/* On error, explain, then die */
	if (sf_error(sndfile) > 0) {
		fprintf(stderr, "Error: %s\n", sf_strerror(sndfile));
		free(sfinfo);
		return 0;
	}

	/* Prepare fingerprint generator */
	t_fooid *fid;
	unsigned int frames = sfinfo->frames * 100;
	int rate = sfinfo->samplerate;
	unsigned int songlen = frames / rate;
	fid = fp_init(sfinfo->samplerate, sfinfo->channels);
		
	/* Print data about file */
	fprintf(stderr, "File data:\tPath:\t\t\t%s\n", infile);
	fprintf(stderr, "\t\tChannels:\t\t%d\n\t\tSample rate (Hz):\t%d\n\t\tFrames:\t\t\t%d\n", sfinfo->channels, sfinfo->samplerate, sfinfo->frames);
	fprintf(stderr, "\t\tLength (cs):\t\t%d\n", songlen);
	
	/* Read data and feed to generator */
	int datasize = sfinfo->channels * sizeof(float);
	float *snddata = malloc(datasize);
	sf_count_t count = 0;
	int feed = 1;
	while (feed == 1) {
		count += sf_readf_float(sndfile, snddata, 1);
		feed = fp_feed_float(fid, snddata, datasize);
	}
	int pcread = count * 100 / sfinfo->frames;
	/* fprintf(stderr, "%% to generator:\t%d\n", pcread); */
	
	/* Generate fingerprint */
	int result = fp_calculate(fid, songlen);
	
	/* Close files and free memory */
	free(sfinfo);
	sf_close(sndfile);
	free(snddata);

	if (result == 0) {
		fprintf(stderr, "Fingerprint for %s generated successfully\n\n", infile);
		data->fid = fid;
		return 1;
	} else {
		fprintf(stderr, "Fingerprint generation failed for %s\n\n", infile);
		return 0;
	}

}

wt_data * wt_generateFingerprint2(char *infile) {
	wt_data *data = malloc(sizeof(wt_data));
	data->data = infile;
	if (wt_generateFingerprint(data))
		data->value = 1;
	else
		data->value = 0;
	return data;
}

int wt_outputFingerprint(wt_data *data) {
	int retval, error;
	FILE *fd = fopen(data->data, "wb");
	if (fd == NULL) {
		perror("File open error");
		return -1;
	}
	retval = fwrite(&(data->fid->fp), 1, fp_getsize(data->fid), fd);
	if (retval < 0)
		perror("File write error");
	else
		fprintf(stderr, "%s written.\n", data->data);
	fclose(fd);
	return retval;
}

int wt_outputFingerprint2(t_fooid *fid, char *outfile) {
	wt_data *data = malloc(sizeof(wt_data));
	data->data = outfile;
	data->fid = fid;
	int retval = wt_outputFingerprint(data);
	free(data);
	return retval;
}

float wt_fullMatch(t_fingerprint *fpA, t_fingerprint *fpB) {
	/* Java original of this function (C) 2006 Gian-Carlo Pascutto
	   See http://www.foosic.org/libfooid/matching.zip
	*/

	if (fpA->version != fpB->version || fpA->version != 0) {
		puts("fp version mismatch...");
	}

        /*
            determine max sensible frame
        */
        unsigned int maxframeA = fpA->length * 0.9765625 / 100.0;
        unsigned int maxframeB = fpB->length * 0.9765625 / 100.0;
        unsigned int maxframe = min(87,max(maxframeA, maxframeB));
        //printf("maxframe: %d\n", maxframe);

        /*
            set up 'flaw' counters
        */
        int rcount = 4;
        int rf[4];
        int df[66];
        int tdf, trf;
        int f, i, b;

        tdf = 0;
        trf = 0;

        for (i = 0; i <= 66; i++)
            df[i] = 0;
            
        for (i = 0; i <= rcount; i++)
            rf[i] = 0;
        
        int maxrflaw = 9 * 16 * maxframe;
        int maxdflaw = (63 * maxframe) / 4;
        int maxflaws = maxrflaw + maxdflaw;

        for (f = 0; f <= maxframe; f++) {
            for (b = 0; b <= 16; b++) {
                int rdiff = fabs(fpA->r[f * b] - fpB->r[f * b]);
                if (rdiff <= rcount)
	                rf[rdiff]++;
                trf += rdiff;
            }
            int ddiff = fabs(fpA->dom[f] - fpB->dom[f]);
            if (ddiff <= 66)
	            df[ddiff]++;
            tdf += ddiff;
        }

        /*
            DOM flaws are linear, penality points = how far we're off

            FIT flaws are nonlinear
                1-off:  1 penalty point
                2-off:  3 penalty points
                3-off:  9 penalty points
        */

        int w_trf = rf[1] + rf[2] * 4 + rf[3] * 9;
        int w_tdf = tdf / 4;

        int totalflaws = w_trf + w_tdf;

        
        //printf("maxflaws: %d\ntotalflaws: %d\n", maxflaws, totalflaws);

        /*
            percentage is ratio of our
            flaws to max theorethical flaws
        */
        float perc = (float) totalflaws / (float) maxflaws;
        perc = ceil(perc * 100) / 100;
        //printf("perc: %f\n", perc);
        /*
            we expect a random track to get
            about halfway there, so confidence
            of 50% -> 0%, and a match to get
            nowhere, so confidence of 0% -> 100%
        */
        float conf = ((1.0 - perc) - 0.5) * 2.0;
        /*
            limit to sane values
        */
        conf = min(conf, 1.0);
        conf = max(conf, 0.0);
	//printf("conf: %f\n", conf);
        return conf;
    }

int wt_possibleMatch(t_fingerprint *fpA, t_fingerprint *fpB) {
	/* Java original of this function (C) 2006 Gian-Carlo Pascutto
	   See http://www.foosic.org/libfooid/matching.zip
	*/
	
	//printf("pM:: %d,%d\n", fpA->avg_fit, fpB->avg_fit);

        /*
            average FIT within 0.4
        */
       	if (fpA->avg_fit + 400 < fpB->avg_fit)
            return 0;	if (fpA->avg_fit - 400 > fpB->avg_fit)
            return 0;
        /*
            average DOM within 6 units
        */
        if (fpA->avg_dom + 600 < fpB->avg_dom)
            return 0;
        if (fpA->avg_dom - 600 > fpB->avg_dom)
            return 0;
	
       	return 1;
}
