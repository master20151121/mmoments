/* what-tune - Audio fingerprint generator/comparison tool
   Copyright (C) 2007 Toby Smithe <tsmithe@ubuntu.com>
   Portions copyright (C) 2006 Gian-Carlo Pascutto
   
   Licensed under the GPLv3 as described in COPYING:

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/

#ifndef _LIB_WHAT_TUNE_H
#define _LIB_WHAT_TUNE_H

#define _LIB_WHAT_TUNE_VERSION_MAJOR 1
#define _LIB_WHAT_TUNE_VERSION_MINOR 1

#include <sndfile.h>
#include <math.h>
#include <fooid.h>
#include <stdio.h>

typedef struct {
	t_fooid *fid;
	void *data;
	int value;
} wt_data ;

typedef struct {
	int major;
	int minor;
} wt_version;


/* Get the library version */
wt_version wt_getVersion();

/* Output a fingerprint to a file.

   data->data contains a string path to the output file.
   data->fid contains the fingerprint descriptor (as from libfooid, or from
    wt_generateFingerprint(...).
   data->value is unused.
   
   Returns 1 on success, 0 on failure.
*/
int wt_outputFingerprint(wt_data *data);

/* Output a fingerprint to a file.
   
   fid is the fingerprint descriptor.
   outfile is the string path to the output file.
   
   Returns 1 on success, 0 on failure.
*/
int wt_outputFingerprint2(t_fooid *fid, char *outfile);

/* Generate a fingerprint.

   data->data must be a string path to the input file
   data->fid is the fingerprint storage
   data->value is unused
   
   Returns 1 on success, 0 on failure.   
*/
int wt_generateFingerprint(wt_data *data);

/* Generate a fingerprint.

   infile is the string path to the input file.
   The returned wt_data struct has contents:
   	wt_data->data contains the input file path, as provided to the function.
   	wt_data->fid is the fingerprint storage.
   	wt_data->value is the return value of the function.
   	 (1 if successful; 0 if not).
*/
wt_data * wt_generateFingerprint2(char *infile);

/* Calculate the possibility of a match of two fingerprints, fpA and fpB.
   
   fpA (and fpB) are t_fingerprint structures, as within the t_fooid structs.
    (See the libfooid header files for more information)
   
   Return values 0.0 to 1.0, with 1.0 being a perfect match.
*/
float wt_fullMatch(t_fingerprint *fpA, t_fingerprint *fpB);

/* Check the possibility of a match of two fingerprints, fpA and fpB.

   fpA and fpB are as above.
   
   Returns 0 if a match is highly unlikely, 1 if possible.
*/
int wt_possibleMatch(t_fingerprint *fpA, t_fingerprint *fpB);


#endif
