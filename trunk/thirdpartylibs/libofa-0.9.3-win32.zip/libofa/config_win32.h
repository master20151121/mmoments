/* config_win32.h configure header for windows  */

/* Use libfftw3 */
#define FFTW3

/* Version number of package */
#define VERSION "0.9.0"

