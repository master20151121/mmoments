/*
    libFooID - Free audio fingerprinting library
    Copyright (C) 2006 Gian-Carlo Pascutto, Hogeschool Gent
    Copyright (C) 2007 Toby Smithe

    Use of this software is allowed under either:
    
    1) The GNU General Public License (GPL), as described 
       in LICENSE.GPL.
    
    2) A modified BSD License, as described in LICENSE.BSDA.
    
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
*/

#ifndef FOOID_H
#define FOOID_H

#if defined(__cplusplus)
extern "C" {
#endif
#if defined(_WIN32) && defined(DYNAMIC)
#ifdef LIBFOOID_EXPORTS
#define FOOIDAPI _declspec(dllexport)
#else
#define FOOIDAPI _declspec(dllimport)
#endif
#else
#define FOOIDAPI
#endif

#ifdef __GNUC__
    #define min(a,b)    ((a) < (b) ? (a) : (b))
    #define max(a,b)	((a) > (b) ? (a) : (b)) 
#endif

#define FRAME_LEN                8192
#define SPEC_LEN       (FRAME_LEN / 2)
#define MAX_BARK                   17

typedef struct t_fooid t_fooid;
typedef struct t_fingerprint t_fingerprint;

/*
    fingerprint storage
*/
struct t_fingerprint
{
    /*
        fingerprint version
    */
    short version;
    /* 
        length in centiseconds         
    */
    int length;
    /* 
        average line fit, times 1000 
    */
    short avg_fit;
    /* 
        average dominant line, times 100 
    */        
    short avg_dom;    
    /*
        spectral fits, 4 bits times 16 bands = 32 times 87 frames
        -> 348 bytes
    */
    unsigned char r[348];
    /*
        spectral doms, 6 bits times 87 frames = 65.25
    */
    unsigned char dom[66];        
};

/*
    processing storage
*/
struct t_fooid
{
    /*  spectral stuff */
    float window[SPEC_LEN];
    int line_to_cb[SPEC_LEN];
    int cb_start[MAX_BARK];
    int cb_size[MAX_BARK];
    int max_sfb;
    
    /*  settings stuff */
    int channels;
    int samplerate;
    
    /* buffer stuff */
    float *samples;
    float *sbuffer;    
    int soundfound;    
    
    /* resampling stuff */
    float resample_ratio;    
    void *resample_h;
    int outpos;
        
    /* actual fingerprint */
    struct t_fingerprint fp;    
};

/*
    Set up library for generating fingerprints for
    file with a given sampling rate and number of
    channels.
    
    input  * sampling rate in Hz 
           * number of channels
    
    output * handle to fingerprinter
             (NULL on error)
             
*/    
FOOIDAPI t_fooid * fp_init(int samplerate, int channels);

/*
    Free a fingerprinter handle.        
*/
FOOIDAPI void fp_free(t_fooid * fid);

/*
    Feed a buffer of samples to the fingerprinting
    generator. The sample buffer size should be a 
    multiple of the number of channels indicated
    earlier. Buffer layout is data[length][channels].
    You should keep feeding data as long as this
    function returns TRUE, or until you have no
    more data to feed.
    
    input  * fingerprinter handle
           * pointer to buffer of 16-bit signed shorts 
           * length of buffer
          
    output *  1  if more data should be fed
              0  if enough is availabled to generate the fingerprint
            < 0  on error          
*/
FOOIDAPI int fp_feed_short(t_fooid * fi, short *data, int size);

/*
    As above, but for 32-bit IEEE floats.
*/
FOOIDAPI int fp_feed_float(t_fooid * fi, float *data, int size);

/*
    Returns the size of the fingerprint
    that this library will generate.
    
    input  * fingerprinter handle
    
    output *  > 0  size of fingerprint in bytes
              < 0  on error 
*/
FOOIDAPI int fp_getsize(t_fooid *fi);

/*
    Returns the fingerprint version number that
    this library will generate
        
    input  * fingerprinter handle
    
    output * version number
*/
FOOIDAPI int fp_getversion(t_fooid *fi);

/*
    Calculate the fingerprint. 
    You should provide the real, total length of the song.
    Songs which do not contain enough usable data
    to generate a meaningful fingerprint will cause
    an error to be returned.
    
    input  * fingerprinter handle
           * total length of song in centiseconds
           
    output *   0 on success
             < 0 on error
*/
FOOIDAPI int fp_calculate(t_fooid *fi, int songlen);


#if defined(__cplusplus)
} // extern "C"
#endif
#endif
